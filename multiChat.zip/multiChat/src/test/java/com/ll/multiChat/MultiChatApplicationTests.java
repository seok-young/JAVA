package com.ll.multiChat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
